import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class seleniumApp {
	public static void main(String[] args) throws InterruptedException {
		//register the chrome driver
		System.setProperty("webdriver.chrome.driver","C:\\95\\chromedriver.exe");
		//creating an object for chrome driver
		WebDriver wd=new ChromeDriver();
		System.out.println(wd);
		 //maximize the screen
		wd.manage().window().maximize();
		
		//using localhost
		wd.get("http://localhost:8080/");
		wd.findElement(By.id("name")).sendKeys("reshma");
		Thread.sleep(5000);
		wd.findElement(By.id("password-field")).sendKeys("resh@123");
		Thread.sleep(5000);
		wd.findElement(By.id("mail")).sendKeys("resh@c.com");
		Thread.sleep(10000);
		wd.findElement(By.xpath("/html/body/section/div/div[2]/div/div/form/div[4]/button")).click();
		Thread.sleep(10000);
		
		wd.findElement(By.id("name")).sendKeys("reshma");
		Thread.sleep(5000);
		wd.findElement(By.id("password-field")).sendKeys("resh@123");
		Thread.sleep(10000);
		wd.findElement(By.xpath("/html/body/section/div/div[2]/div/div/form/div[3]/button")).click();
		Thread.sleep(10000);
	}
	
}
